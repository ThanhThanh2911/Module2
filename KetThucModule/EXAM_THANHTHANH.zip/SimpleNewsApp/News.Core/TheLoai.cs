﻿namespace News.Core
{
    public partial class TinTuc
    {
        public enum TheLoai
        {
            GiaiTri,
            CongNghe,
            BongBa,
            None
        }
    }
}
